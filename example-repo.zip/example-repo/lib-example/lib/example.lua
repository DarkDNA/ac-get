-- Example Library

function print(str)
  term.write(string.reverse(str))
end