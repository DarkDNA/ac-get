-- Example Startup.

print("Yo, I herd u like startup scripts.")